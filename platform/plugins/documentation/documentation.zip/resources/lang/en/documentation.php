<?php

return [
    'name' => 'Documentations',
    'link' => 'Documentation Link',
    'link_placeholder' => 'Enter ducumentation link',
    'create' => 'New documentation',
    'title_link' => 'Link',
    'title_name' => 'Name',
    'topics'=>'Topics',
    'articles'=>'Articles',
    'direction' => 'Direction',
    'please_select_direction' => "Please select layout direction",
    'rtl' => 'RTL',
    'ltr' => 'LTR',
];
