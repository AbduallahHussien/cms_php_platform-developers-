<?php

return [
    'name' => 'الفئات', 
    'create' => 'فئة جديدة',
    'order' => 'الترتيب',
];
