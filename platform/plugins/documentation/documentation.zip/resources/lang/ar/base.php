<?php 

return [
    'short_code_name' => 'توثيق',
    'short_code_description' => 'قم بإضافة توثيق',
];