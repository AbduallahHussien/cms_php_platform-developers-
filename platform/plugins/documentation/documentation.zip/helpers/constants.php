<?php

if (! defined('LTR')) {
    define('LTR', 'LTR');
}

if (! defined('RTL')) {
    define('RTL', 'RTL');
}