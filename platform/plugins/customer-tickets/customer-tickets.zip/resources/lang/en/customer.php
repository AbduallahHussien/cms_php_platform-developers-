<?php

return [
    'name' => 'Customers',
    'create' => 'New customer',
    'phone-placeholder'=>'Enter phone number'

];
