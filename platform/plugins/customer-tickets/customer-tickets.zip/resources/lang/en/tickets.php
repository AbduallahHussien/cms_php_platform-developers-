<?php

return [
    'name' => 'Tickets',
    'create' => 'New tickets',
    'ticket_type' => 'Ticket Type',
    'ticket_level' => 'Ticket Level',
    'description' => 'Description',
    'description_placeholder' => 'Enter description...',
    'customer' => 'Customer Name',

];
