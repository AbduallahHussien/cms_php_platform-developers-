<?php

return [
    'name' => 'Customer tickets',
    'create' => 'New customer tickets',
];
