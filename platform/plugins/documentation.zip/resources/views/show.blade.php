@extends('plugins/documentation::layouts.app')


@section('content')
    {!! $article->content !!}
@endsection

@push('scripts') 

@endpush