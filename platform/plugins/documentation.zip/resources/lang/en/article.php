<?php

return [
    'name' => 'Articles',  
    'create' => 'New Article',
    'title' => 'Title',
    'content' => 'Content',
    'topic' => 'Topic',
    'author' => 'Author',
    'order' => 'Order',
];
