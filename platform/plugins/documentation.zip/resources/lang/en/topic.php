<?php

return [
    'name' => 'Topics', 
    'create' => 'New Topic',
    'order' => 'Order',
];
