<?php 

return [
    'short_code_name' => 'Documenation',
    'short_code_description' => 'Add Documentation',
];