<?php

return [
    'name' => 'المقالات', 
    'create' => 'مقالة جديدة',
    'title' => 'عنوان',
    'content' => 'نص المقال',
    'topic' => 'الفئة',
    'author' => 'المؤلف',
    'order' => 'الترتيب',
];
