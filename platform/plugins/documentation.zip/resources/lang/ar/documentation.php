<?php

return [
    'name' => 'التوثيقات',
    'link' => 'رابط التوثيق',
    'title_link' => 'رابط التوثيق',
    'link_placeholder' => 'أدخل رابط التوثيق',
    'create' => 'توثيق جديد',
    'title_name' => 'اسم التوثيق',
    'topics'=>'الفئات',
    'articles'=>'المقالات',
    'direction' => 'اتجاه العرض',
    'rtl' => 'من اليمين إلى اليسار',
    'ltr' => 'من اليسار إلى اليمين',
    'please_select_direction' => 'الرجاء اختيار اتجاه العرض',
];
