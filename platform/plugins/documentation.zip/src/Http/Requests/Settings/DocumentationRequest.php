<?php

namespace Botble\Documentation\Http\Requests\Settings;

use Botble\Support\Http\Requests\Request;

class DocumentationRequest extends Request
{
    public function rules(): array
    {
        return [];
    }
}
